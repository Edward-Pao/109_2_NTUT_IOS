//
//  swift0426App.swift
//  swift0426
//
//  Created by Mac on 2021/4/26.
//

import SwiftUI

@main
struct swift0426App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  ContentView.swift
//  swift0426
//
//  Created by Mac on 2021/4/26.
//

import SwiftUI

struct ContentView: View {
    //toSecondPage
    @State private var toSecondPage = false
    
    //DiceGame
    @State private var number1 = 1
    @State private var number2 = 1
    @State private var number3 = 1
    @State private var coin = 1000
    @State private var result = ""
    @State private var predict = ""
    
    var body: some View {
        
        
        //navigation_CatView
        NavigationView{
            
            VStack(spacing: 20){
                Image("IMDB")
                    .frame(width: 500, height: 300, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                Spacer()
                NavigationLink(
                    destination: Introduce(),
                    label: {
                        Text("介紹")
                            
                    })
                
                NavigationLink(
                    destination: RankView(),
                    label: {
                        Text("電影排行")
                    })
            }
            .navigationTitle("IMDb 電影排行")
            
           
        }
        
        
        //toSecondPage_loginView
        Button(action: {
            toSecondPage=true
        }, label: {
            Text("Button")
        })
        .sheet(isPresented: $toSecondPage, content: {
            loginView(toSecondPage: $toSecondPage)
        })
        
        
        
        
        
        
        //DiceGame
        VStack{
            
            HStack{
                DicePicture(dicPic: number1, diceNum: 1)
            }
            HStack{
                DicePicture(dicPic: number2, diceNum: 2)
            }
            HStack{
                DicePicture(dicPic: number3, diceNum: 3)
            }
            TextField("請輸入猜測結果", text: $predict)
                .padding(.leading,130.0)
                .keyboardType(.numberPad)
            

            Button(action: {
                
                let predictValue = (predict as NSString).integerValue
                if predict != "" {
                    number1 = Int.random(in: 1...6)
                    number2 = Int.random(in: 1...6)
                    number3 = Int.random(in: 1...6)
                    
                    if (predictValue>(number1+number2+number3))
                    {
                        coin+=100
                        result="猜測成功 ＋100元"
                    }else{
                        coin-=100
                        result="猜測失敗 -100元"
                    }
                }else{
                    result="請輸入數字"
                }
            }, label: {
                Text("Start")
                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 30, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .background(Color.gray)
                    .foregroundColor(.white)
                    
                    .cornerRadius(15.0)
                    .padding()
                    
            })
            Text("猜測結果：\(result)")
                .padding(.leading,10.0)
            Text("目前金額：\(coin)")
                .padding(.top,10.0)
        }
        
        VStack{
            Image(systemName: "wifi")
                .resizable()
                .frame(width: 30, height: 30, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            Image("kirua")
                .resizable()
                .scaledToFill()
                .frame(width: 300, height: 300
                       , alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                .shadow(radius: 100)
                .opacity(0.7)
                
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct DicePicture: View {
    let dicPic : Int
    let diceNum : Int
    var body: some View {
        Image(systemName: "die.face.\(dicPic)")
            .resizable()
            .frame(width: 100, height: 100, alignment: .center)
            .padding()
        
        Text("骰子 \(diceNum) 數字: \(dicPic)")
            .padding()
            .font(.title2)
    }
}

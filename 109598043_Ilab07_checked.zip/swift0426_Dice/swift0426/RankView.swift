//
//  RankView.swift
//  swift0426
//
//  Created by Mac on 2021/5/5.
//

import SwiftUI

struct RankView: View {
    struct  movie:Identifiable{
        var id=UUID()
        var name:String
        var year:String
        
    }
    var movies=[movie(name:"The Shawshank Redemption 肖申克的救贖",year:"(1994)"),
               movie(name:"The Godfather 教父",year:"(1972)"),
               movie(name:"The Godfather: Part II 教父續集",year:"(1974)"),
               movie(name:"The Dark Knight 蝙蝠俠:黑暗騎士",year:"(2008)"),
               movie(name:"12 Angry Men 十二怒漢",year:"(1957)")]
    
    var body: some View {
        
        VStack{
            Image("IMDB")
            ForEach(movies){ movies in
                VStack {
                    Text("\(movies.name) ")
                    Text("in \(movies.year) ")
            
                }
            }
            .padding(.top,40)
        }
        
        
        
        
    }
}

struct RankView_Previews: PreviewProvider {
    static var previews: some View {
        RankView()
    }
}

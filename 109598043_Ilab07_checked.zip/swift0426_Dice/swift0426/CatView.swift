//
//  CatView.swift
//  swift0426
//
//  Created by Mac on 2021/5/3.
//

import SwiftUI

struct CatView: View {
    @State var name:String
    
    var body: some View {
        Image("\(name)")
    }
}

struct CatView_Previews: PreviewProvider {
    static var previews: some View {
        CatView(name:"IMDB")
    }
}

//
//  loginView.swift
//  swift0426
//
//  Created by Mac on 2021/5/3.
//

import SwiftUI

struct loginView: View {
    
    @Binding var toSecondPage:Bool
    var body: some View {
        
       
        ZStack{
            Color.yellow
                .edgesIgnoringSafeArea(.all)
            Text("Hello, it's Second View!")
            
            }
        .overlay(Button(action: {toSecondPage=false}, label: {
            Image(systemName: "xmark.circle.fill")
                .resizable()
                .frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .padding(20)
        }),alignment: .topTrailing)
        }
    }
    


struct loginView_Previews: PreviewProvider {
    static var previews: some View {
        loginView(toSecondPage: .constant(true))
    }
}

//
//  Introduce.swift
//  swift0426
//
//  Created by Mac on 2021/5/5.
//

import SwiftUI

struct Introduce: View {
    var body: some View {
        VStack {
            
            Image("IMDB")
                .frame(width: 500, height: 200, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .padding(.top,60)
            Text("網路電影資料庫（英語：Internet Movie Database，簡稱IMDb）是一個關於電影演員、電影、電視節目、電視藝人、電子遊戲和電影製作小組的線上資料庫。IMDb開辦於1990年10月17日，從1998年開始成為亞馬遜公司旗下的網站，在2020年10月17日時，IMDb慶祝了他們30週年的紀念。")
                .padding(.top,30)
                .padding([.leading,.trailing],20)
                
            Spacer()
        }
        
        
       
    }
    
}

struct Introduce_Previews: PreviewProvider {
    static var previews: some View {
        Introduce()
    }
}

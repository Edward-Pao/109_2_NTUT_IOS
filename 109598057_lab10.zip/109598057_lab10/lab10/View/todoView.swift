//
//  todoView.swift
//  lab10
//
//  Created by Ming on 2021/6/1.
//

import SwiftUI

struct TodoView: View {
    let todo: Todo
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("名稱： \(todo.name)\n是否完成： \(todo.check)\n到期時間： \(todo.time)")
        }
    }
}

struct SongView_Previews: PreviewProvider {
    static var previews: some View {
        TodoView(todo: .previewData)
    }
}

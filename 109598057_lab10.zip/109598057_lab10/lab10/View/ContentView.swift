//
//  ContentView.swift
//  lab10
//
//  Created by Ming on 2021/6/1.
//

import SwiftUI
import FirebaseFirestore


struct ContentView: View {
    @State var todoViewModel = TodoViewModel()
    @State var hama: [Todo] = []
    @State var name: String = ""
    @State var check: String = ""
    @State var now_name: String = "無"
    @State var now_check: String = "無"
    @State var now_time: String = "無"
    @State private var snackTime = Date()
    var body: some View {
        VStack{
            Text("ToDo App").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
            Text("請輸入待辦事項").font(.title2) .foregroundColor(.gray).padding(.top, 30.0)
            HStack{
                Text("事項名稱：")
                TextField("請輸入名稱", text: $name)
            }
            HStack{
                Text("是否完成：")
                TextField("請輸入是或者否", text: $check)
            }
            HStack{
                DatePicker("到期時間：", selection: $snackTime)
            }
            Button(action: {
                let db = Firestore.firestore()
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                let todo = Todo(name: name
                                , check:check , time: dateFormatter.string(from: snackTime))
                do {
                    let documentReference = try db.collection("todo").addDocument(from: todo)
                    print(documentReference.documentID)
                } catch {
                    print(error)
                }
            }) {
                Text("新增數據").font(.title3)
            }
            Text("-----------------------").font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
            Text("目前數據").font(.title2) .foregroundColor(.gray).padding(.top, 30.0)
            List(hama) { todo in
                TodoView(todo: todo)
            }
            
            Button(action: {
                let db = Firestore.firestore()
                  db.collection("todo").getDocuments { snapshot, error in
                          
                       guard let snapshot = snapshot else { return }
                      
                       let todos = snapshot.documents.compactMap { snapshot in
                           try?
                            hama.append(snapshot.data(as: Todo.self)!)
                       }
                          
                   }
            }) {
                Text("讀取數據").font(.title3)
            }
           
           
            
        }.padding(.horizontal)
        
    }
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

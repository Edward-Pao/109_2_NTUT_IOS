//
//  lab10App.swift
//  lab10
//
//  Created by Ming on 2021/6/1.
//

import SwiftUI

@main
struct lab10App: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  ToDoViewModel.swift
//  lab10
//
//  Created by Ming on 2021/6/1.
//

import Foundation
import FirebaseFirestore
class TodoViewModel: ObservableObject {
    @Published var todos: [Todo] = []
    private let store = Firestore.firestore()
    
   
    
    
    func fetchChanges() {
        store.collection("todo").addSnapshotListener { snapshot, error in
            guard let snapshot = snapshot else { return }
            snapshot.documentChanges.forEach { documentChange in
                guard let todo = try? documentChange.document.data(as: Todo.self) else { return }
                switch documentChange.type {
                case .added:
                    self.todos.append(todo)
                case .modified:
                    guard let index = self.todos.firstIndex(where: {
                        $0.id == todo.id
                    }) else { return }
                    self.todos[index] = todo
                case .removed:
                    guard let index = self.todos.firstIndex(where: {
                        $0.id == todo.id
                    }) else { return }
                    self.todos.remove(at: index)
                }
            }
        }
    }
}

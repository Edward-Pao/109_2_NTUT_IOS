//
//  ToDo.swift
//  lab10
//
//  Created by Ming on 2021/6/1.
//

import Foundation
import FirebaseFirestoreSwift

struct Todo: Codable, Identifiable {
    @DocumentID var id: String?
    let name: String
    let check: String
    let time: String
}

extension Todo {
    static var previewData: Todo {
        Todo(name: "無", check: "無", time:"無")
    }
}
